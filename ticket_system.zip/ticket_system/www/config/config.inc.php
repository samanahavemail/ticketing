<?php
	$host = "172.18.0.1";
	$user = "admin";
	$pass = "123456";
	$port = 3306;
	$database = "ticket_db";
	
	#localhost
	#$host = "localhost";
	#$user = "root";
	#$pass = "";
	#$port = 3306;
	#$database = "khonkaenev_eventstat";
?>
